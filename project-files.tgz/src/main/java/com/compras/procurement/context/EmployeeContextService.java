package com.compras.procurement.context;

import com.compras.procurement.shared.NotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Builds the requester's context from the (mock) HR directory and asset register.
 * Swapping the mocks for real systems only touches this class.
 */
@Service
public class EmployeeContextService {

    private final EmployeeRepository employees;
    private final AssetRepository assets;

    public EmployeeContextService(EmployeeRepository employees, AssetRepository assets) {
        this.employees = employees;
        this.assets = assets;
    }

    public List<Employee> allEmployees() {
        return employees.findAll();
    }

    public Employee employee(String id) {
        return employees.findById(id).orElseThrow(() -> new NotFoundException("Unknown employee " + id));
    }

    public EmployeeContext contextFor(String employeeId) {
        Employee employee = employee(employeeId);
        List<Asset> visible = new ArrayList<>(assets.findByAssignedTo(employeeId));
        visible.addAll(assets.findBySiteAndAssignedToIsNull(employee.site()));
        return new EmployeeContext(employee, visible);
    }
}
