package com.compras.procurement.intake;

import com.compras.procurement.resolution.ResolvedLine;
import com.compras.procurement.rules.RuleViolation;

import java.math.BigDecimal;
import java.util.List;

/** Deterministic verdict on a draft: its lines, price, rule findings and what is still missing. */
public record DraftAssessment(
        List<ResolvedLine> lines,
        BigDecimal estimatedTotal,
        List<RuleViolation> violations,
        List<String> missingFields
) {
    public boolean readyToSubmit() {
        return missingFields.isEmpty() && violations.stream().noneMatch(RuleViolation::blocking) && !lines.isEmpty();
    }

    public List<RuleViolation> warnings() {
        return violations.stream().filter(v -> !v.blocking()).toList();
    }
}
