package com.compras.procurement.consolidation;

import com.compras.procurement.request.PurchaseRequest;
import com.compras.procurement.request.RequestService;
import com.compras.procurement.shared.Events;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.time.Clock;
import java.time.Instant;
import java.util.List;

/** Subscribes to approvals: approved lines enter the pool; urgent ones are ordered straight away. */
@Component
public class PoolingListener {

    private final RequestService requests;
    private final DemandLineRepository lines;
    private final ConsolidationService consolidation;
    private final ApplicationEventPublisher events;
    private final Clock clock;

    public PoolingListener(RequestService requests, DemandLineRepository lines, ConsolidationService consolidation,
                           ApplicationEventPublisher events, Clock clock) {
        this.requests = requests;
        this.lines = lines;
        this.consolidation = consolidation;
        this.events = events;
        this.clock = clock;
    }

    @EventListener
    public void on(Events.RequestApproved event) {
        PurchaseRequest request = requests.get(event.requestId());
        Instant now = Instant.now(clock);
        List<DemandLine> pooled = lines.saveAll(request.getLines().stream()
                .map(l -> new DemandLine(request.getId(), request.getNumber(), request.getRequester().name(),
                        request.getRequester().department(), l.sku(), l.name(), l.supplierId(),
                        request.getDeliverySite(), l.quantity(), request.getNeededBy(), request.isUrgent(), now))
                .toList());
        requests.markPooled(request.getId());
        events.publishEvent(new Events.DemandPooled(request.getId(), pooled.stream().map(DemandLine::getId).toList(), now));
        if (request.isUrgent()) {
            consolidation.releaseUrgent(request.getId());
        }
    }
}
