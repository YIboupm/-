package com.compras.procurement.request;

import com.compras.procurement.rules.RuleViolation;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * The standardised, storable purchase request: the output of intake and the input of
 * approval and consolidation. {@code attributes} keeps the category-specific fields as-is,
 * which is the part a document database handles well.
 */
@Document("purchase_requests")
public class PurchaseRequest {

    public record Requester(String employeeId, String name, String department, String costCenter, String site) {
    }

    public record Line(String lineId, String sku, String name, String categoryCode, int quantity,
                       BigDecimal estimatedUnitPrice, BigDecimal estimatedTotal,
                       String supplierId, String supplierName, int leadTimeDays, String note) {
    }

    public record StatusChange(RequestStatus from, RequestStatus to, Instant at, String note) {
    }

    @Id
    private String id;
    @Indexed(unique = true)
    private String number;
    @Version
    private Long version;
    private String conversationId;
    private String channel;
    private Requester requester;
    private String categoryCode;
    private String categoryName;
    private Map<String, Object> attributes;
    private Map<String, String> attributeSources;
    private List<Line> lines;
    private BigDecimal estimatedTotal;
    private String currency;
    private LocalDate neededBy;
    private String deliverySite;
    private boolean urgent;
    private List<RuleViolation> warnings;
    @Indexed
    private RequestStatus status;
    private List<StatusChange> history = new ArrayList<>();
    private Instant submittedAt;

    protected PurchaseRequest() {
    }

    public PurchaseRequest(String number, String conversationId, String channel, Requester requester,
                           String categoryCode, String categoryName, Map<String, Object> attributes,
                           Map<String, String> attributeSources, List<Line> lines, BigDecimal estimatedTotal,
                           String currency, LocalDate neededBy, String deliverySite, boolean urgent,
                           List<RuleViolation> warnings, Instant submittedAt) {
        this.number = number;
        this.conversationId = conversationId;
        this.channel = channel;
        this.requester = requester;
        this.categoryCode = categoryCode;
        this.categoryName = categoryName;
        this.attributes = attributes;
        this.attributeSources = attributeSources;
        this.lines = lines;
        this.estimatedTotal = estimatedTotal;
        this.currency = currency;
        this.neededBy = neededBy;
        this.deliverySite = deliverySite;
        this.urgent = urgent;
        this.warnings = warnings;
        this.status = RequestStatus.SUBMITTED;
        this.submittedAt = submittedAt;
        this.history.add(new StatusChange(null, RequestStatus.SUBMITTED, submittedAt, "Submitted via " + channel));
    }

    /** Moves the request along its state machine; rejects transitions the lifecycle does not allow. */
    public void moveTo(RequestStatus target, Instant at, String note) {
        if (!status.canMoveTo(target)) {
            throw new IllegalStateException("Request " + number + " cannot move from " + status + " to " + target);
        }
        history.add(new StatusChange(status, target, at, note));
        status = target;
    }

    public String getId() { return id; }
    public String getNumber() { return number; }
    public String getConversationId() { return conversationId; }
    public String getChannel() { return channel; }
    public Requester getRequester() { return requester; }
    public String getCategoryCode() { return categoryCode; }
    public String getCategoryName() { return categoryName; }
    public Map<String, Object> getAttributes() { return attributes; }
    public Map<String, String> getAttributeSources() { return attributeSources; }
    public List<Line> getLines() { return lines; }
    public BigDecimal getEstimatedTotal() { return estimatedTotal; }
    public String getCurrency() { return currency; }
    public LocalDate getNeededBy() { return neededBy; }
    public String getDeliverySite() { return deliverySite; }
    public boolean isUrgent() { return urgent; }
    public List<RuleViolation> getWarnings() { return warnings; }
    public RequestStatus getStatus() { return status; }
    public List<StatusChange> getHistory() { return history; }
    public Instant getSubmittedAt() { return submittedAt; }
}
