package com.compras.procurement.consolidation;

import com.compras.procurement.catalog.CatalogItem;
import com.compras.procurement.catalog.CatalogService;
import com.compras.procurement.request.RequestService;
import com.compras.procurement.shared.Events;
import com.compras.procurement.shared.Money;
import com.compras.procurement.shared.SequenceService;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Runs the demand pool: previews groups, releases them into consolidated purchase orders and
 * moves the underlying requests forward.
 *
 * Concurrency: a line is claimed with an atomic conditional update (status POOLED -> ORDERED).
 * If two runs overlap, each line still ends up on exactly one order, without needing
 * multi-document transactions.
 */
@Service
public class ConsolidationService {

    private static final Logger log = LoggerFactory.getLogger(ConsolidationService.class);

    private final DemandLineRepository lines;
    private final ConsolidatedOrderRepository orders;
    private final ConsolidationPlanner planner;
    private final CatalogService catalog;
    private final RequestService requests;
    private final PurchaseOrderGateway gateway;
    private final SequenceService sequences;
    private final MongoTemplate mongo;
    private final ApplicationEventPublisher events;
    private final Clock clock;

    public ConsolidationService(DemandLineRepository lines, ConsolidatedOrderRepository orders,
                                ConsolidationPlanner planner, CatalogService catalog, RequestService requests,
                                PurchaseOrderGateway gateway, SequenceService sequences, MongoTemplate mongo,
                                ApplicationEventPublisher events, Clock clock) {
        this.lines = lines;
        this.orders = orders;
        this.planner = planner;
        this.catalog = catalog;
        this.requests = requests;
        this.gateway = gateway;
        this.sequences = sequences;
        this.mongo = mongo;
        this.events = events;
        this.clock = clock;
    }

    /** What would happen if the scheduler ran on {@code asOf}. No side effects. */
    public List<GroupDecision> preview(LocalDate asOf) {
        return planner.plan(lines.findByStatus(DemandLine.Status.POOLED), itemsBySku(), asOf);
    }

    /** Daily automatic run. */
    @Scheduled(cron = "${procurement.consolidation.cron}")
    public void scheduledRun() {
        RunReport report = run(LocalDate.now(clock));
        log.info("Scheduled consolidation: {} order(s), savings {}", report.ordersCreated(), report.savings());
    }

    /** Applies the policies as of {@code asOf} and releases every group that qualifies. */
    public RunReport run(LocalDate asOf) {
        List<GroupDecision> result = new ArrayList<>();
        BigDecimal savings = BigDecimal.ZERO;
        int created = 0;
        for (GroupDecision decision : preview(asOf)) {
            if (decision.release()) {
                ConsolidatedOrder order = release(decision, asOf);
                if (order != null) {
                    created++;
                    savings = savings.add(order.savings());
                    decision = decision.withOrderNumber(order.number());
                }
            }
            result.add(decision);
        }
        return new RunReport(asOf, result, created, Money.scale(savings));
    }

    /** Urgent requests do not wait for the pool. */
    public void releaseUrgent(String requestId) {
        LocalDate today = LocalDate.now(clock);
        Map<String, CatalogItem> items = itemsBySku();
        List<DemandLine> pooled = lines.findByRequestId(requestId).stream()
                .filter(l -> l.getStatus() == DemandLine.Status.POOLED).toList();
        pooled.stream().collect(Collectors.groupingBy(DemandLine::groupKey)).forEach((key, group) -> {
            CatalogItem item = items.get(key.sku());
            if (item != null) {
                release(planner.urgent(new PoolGroup(key, item, group), today), today);
            }
        });
    }

    public List<ConsolidatedOrder> orders() {
        return orders.findAllByOrderByCreatedAtDesc();
    }

    // ------------------------------------------------------------------ internals

    private ConsolidatedOrder release(GroupDecision decision, LocalDate asOf) {
        String orderId = new ObjectId().toHexString();
        String number = sequences.nextNumber("PO");

        List<DemandLine> claimed = decision.lines().stream()
                .map(l -> claim(l.getId(), orderId, number))
                .filter(Objects::nonNull)
                .toList();
        if (claimed.isEmpty()) {
            return null; // another run took these lines first
        }

        CatalogItem item = catalog.item(decision.key().sku());
        int qty = claimed.stream().mapToInt(DemandLine::getQuantity).sum();
        BigDecimal unit = item.unitPriceFor(qty);
        BigDecimal total = Money.times(unit, qty);
        List<ConsolidatedOrder.Allocation> allocations = claimed.stream().map(l -> new ConsolidatedOrder.Allocation(
                l.getId(), l.getRequestId(), l.getRequestNumber(), l.getRequesterName(), l.getDepartment(),
                l.getQuantity(), l.getNeededBy(), item.unitPriceFor(l.getQuantity()),
                Math.max(0, ChronoUnit.DAYS.between(LocalDate.ofInstant(l.getPooledAt(), clock.getZone()), asOf))))
                .toList();
        BigDecimal individual = allocations.stream()
                .map(a -> Money.times(a.individualUnitPrice(), a.quantity()))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        ConsolidatedOrder order = orders.save(new ConsolidatedOrder(orderId, number, item.sku(), item.name(),
                item.supplierId(), item.supplierName(), decision.key().deliverySite(), qty, unit, item.listPrice(),
                total, Money.scale(individual), Money.scale(individual.subtract(total)), item.currency(),
                decision.reasons(), allocations, asOf, Instant.now(clock)));

        gateway.issue(order);
        events.publishEvent(new Events.OrderReleased(order.id(), order.number(), order.sku(), qty,
                decision.reasons().stream().map(Enum::name).toList(), Instant.now(clock)));
        advanceRequests(claimed);
        return order;
    }

    /** Atomic: only a line that is still POOLED can be taken. Returns null if someone else took it. */
    private DemandLine claim(String lineId, String orderId, String orderNumber) {
        return mongo.findAndModify(
                Query.query(Criteria.where("id").is(lineId).and("status").is(DemandLine.Status.POOLED)),
                new Update().set("status", DemandLine.Status.ORDERED).set("orderId", orderId).set("orderNumber", orderNumber),
                FindAndModifyOptions.options().returnNew(true),
                DemandLine.class);
    }

    /** A request becomes ORDERED once none of its lines is left in the pool. */
    private void advanceRequests(List<DemandLine> claimed) {
        Set<String> requestIds = claimed.stream().map(DemandLine::getRequestId).collect(Collectors.toCollection(LinkedHashSet::new));
        for (String requestId : requestIds) {
            if (!lines.existsByRequestIdAndStatus(requestId, DemandLine.Status.POOLED)) {
                List<String> numbers = lines.findByRequestId(requestId).stream()
                        .map(DemandLine::getOrderNumber).filter(Objects::nonNull).distinct().toList();
                requests.markOrdered(requestId, numbers);
            }
        }
    }

    private Map<String, CatalogItem> itemsBySku() {
        return catalog.allItems().stream().collect(Collectors.toMap(CatalogItem::sku, Function.identity()));
    }
}
