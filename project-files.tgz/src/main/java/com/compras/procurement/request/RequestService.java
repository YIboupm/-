package com.compras.procurement.request;

import com.compras.procurement.context.Employee;
import com.compras.procurement.resolution.FieldValues;
import com.compras.procurement.resolution.ResolvedLine;
import com.compras.procurement.shared.Events;
import com.compras.procurement.shared.NotFoundException;
import com.compras.procurement.shared.SequenceService;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * Owns the purchase request and its state machine. Every state change is saved and then
 * announced as a domain event; downstream modules react to the events.
 */
@Service
public class RequestService {

    private final PurchaseRequestRepository repository;
    private final SequenceService sequences;
    private final ApplicationEventPublisher events;
    private final Clock clock;

    public RequestService(PurchaseRequestRepository repository, SequenceService sequences,
                          ApplicationEventPublisher events, Clock clock) {
        this.repository = repository;
        this.sequences = sequences;
        this.events = events;
        this.clock = clock;
    }

    public PurchaseRequest submit(NewRequest input) {
        Employee e = input.requester().employee();
        List<PurchaseRequest.Line> lines = new ArrayList<>();
        int n = 1;
        for (ResolvedLine l : input.lines()) {
            lines.add(new PurchaseRequest.Line(String.valueOf(n++), l.sku(), l.name(), l.categoryCode(), l.quantity(),
                    l.unitPrice(), l.lineTotal(), l.supplierId(), l.supplierName(), l.leadTimeDays(), l.note()));
        }
        Instant now = Instant.now(clock);
        PurchaseRequest request = new PurchaseRequest(
                sequences.nextNumber("PR"),
                input.conversationId(),
                input.channel(),
                new PurchaseRequest.Requester(e.id(), e.name(), e.department(), e.costCenter(), e.site()),
                input.category().code(),
                input.category().name(),
                input.attributes(),
                input.attributeSources(),
                lines,
                input.estimatedTotal(),
                input.currency(),
                FieldValues.date(input.attributes(), "neededBy").orElse(null),
                FieldValues.string(input.attributes(), "deliverySite").orElse(e.site()),
                FieldValues.flag(input.attributes(), "urgent"),
                input.warnings(),
                now);
        request = repository.save(request);
        events.publishEvent(new Events.RequestSubmitted(request.getId(), request.getNumber(), now));
        return request;
    }

    public PurchaseRequest approve(String requestId, String note) {
        PurchaseRequest request = transition(requestId, RequestStatus.APPROVED, note);
        events.publishEvent(new Events.RequestApproved(request.getId(), request.isUrgent(), note, Instant.now(clock)));
        return request;
    }

    public PurchaseRequest markPooled(String requestId) {
        return transition(requestId, RequestStatus.POOLED, "Lines added to the demand pool");
    }

    public PurchaseRequest markOrdered(String requestId, List<String> orderNumbers) {
        PurchaseRequest request = transition(requestId, RequestStatus.ORDERED,
                "On purchase order(s) " + String.join(", ", orderNumbers));
        events.publishEvent(new Events.RequestOrdered(requestId, orderNumbers, Instant.now(clock)));
        return request;
    }

    public PurchaseRequest get(String id) {
        return repository.findById(id).orElseThrow(() -> new NotFoundException("Unknown request " + id));
    }

    public List<PurchaseRequest> all() {
        return repository.findAllByOrderBySubmittedAtDesc();
    }

    private PurchaseRequest transition(String requestId, RequestStatus target, String note) {
        PurchaseRequest request = get(requestId);
        request.moveTo(target, Instant.now(clock), note);
        return repository.save(request);
    }
}
