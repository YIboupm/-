package com.compras.procurement.intake;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.math.BigDecimal;

@ConfigurationProperties("intake")
public record IntakeProperties(
        int maxClarificationRounds,
        BigDecimal budgetApprovalThreshold,
        String currency
) {
}
