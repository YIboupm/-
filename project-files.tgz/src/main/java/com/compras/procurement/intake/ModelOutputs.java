package com.compras.procurement.intake;

import java.util.List;
import java.util.Map;

/** JSON contracts the model must answer with. Parsed by {@link com.compras.procurement.llm.ModelGateway}. */
public final class ModelOutputs {

    private ModelOutputs() {
    }

    public enum Intent { PURCHASE_REQUEST, STATUS_QUERY, POLICY_QUESTION, OTHER }

    /** Step 1: what is this message, and which category template applies? */
    public record Classification(Intent intent, String categoryCode, Double confidence, String reply) {
    }

    /** One proposed field value with its provenance as the model sees it. */
    public record ProposedValue(Object value, String source) {
        public Conversation.Source toSource() {
            return "stated".equalsIgnoreCase(source) ? Conversation.Source.STATED : Conversation.Source.INFERRED;
        }
    }

    /** Step 2: fill the template's fields from the dialogue and ask about what is missing. */
    public record Extraction(Map<String, ProposedValue> fields, String question, List<String> options, String notes) {
    }
}
