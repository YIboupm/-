package com.compras.procurement.intake;

import com.compras.procurement.catalog.CatalogItem;
import com.compras.procurement.catalog.CatalogService;
import com.compras.procurement.catalog.CategoryDefinition;
import com.compras.procurement.catalog.FieldSpec;
import com.compras.procurement.catalog.ResolutionStrategy;
import com.compras.procurement.context.EmployeeContext;
import com.compras.procurement.context.EmployeeContextService;
import com.compras.procurement.llm.ModelGateway;
import com.compras.procurement.matching.Requirement;
import com.compras.procurement.matching.RequirementMatcher;
import com.compras.procurement.request.NewRequest;
import com.compras.procurement.request.PurchaseRequest;
import com.compras.procurement.request.RequestService;
import com.compras.procurement.resolution.FieldValues;
import com.compras.procurement.rules.RuleViolation;
import com.compras.procurement.shared.Events;
import com.compras.procurement.shared.NotFoundException;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Orchestrates the intake dialogue:
 * <ol>
 *   <li>classify the message and pick the category template (model)</li>
 *   <li>prefill what the system already knows (context, no model)</li>
 *   <li>extract field values and the employee's conditions from the dialogue (model, bounded by the template)</li>
 *   <li>normalise and validate every value (rules, no model)</li>
 *   <li>check the conditions against catalog attributes, switching to a better tier if one fits (code, no model)</li>
 *   <li>ask for what is missing, or show the structured request for confirmation</li>
 *   <li>on confirmation, store the standardised request: standard, or special for a buyer</li>
 * </ol>
 */
@Service
public class IntakeService {

    private static final String CHANNEL = "web-chat";
    private static final Pattern URGENT_WORDS = Pattern.compile(
            "urgent|asap|as soon as possible|immediately|right away|emergency|blocking|blocked|urgente|urgencia|急|马上|立刻",
            Pattern.CASE_INSENSITIVE);

    private final ConversationRepository conversations;
    private final CatalogService catalog;
    private final EmployeeContextService employees;
    private final ModelGateway model;
    private final FieldNormalizer normalizer;
    private final DraftEvaluator evaluator;
    private final RequirementMatcher matcher;
    private final RequestService requests;
    private final IntakeProperties properties;
    private final ApplicationEventPublisher events;
    private final Clock clock;

    public IntakeService(ConversationRepository conversations, CatalogService catalog,
                         EmployeeContextService employees, ModelGateway model, FieldNormalizer normalizer,
                         DraftEvaluator evaluator, RequirementMatcher matcher, RequestService requests,
                         IntakeProperties properties, ApplicationEventPublisher events, Clock clock) {
        this.conversations = conversations;
        this.catalog = catalog;
        this.employees = employees;
        this.model = model;
        this.normalizer = normalizer;
        this.evaluator = evaluator;
        this.matcher = matcher;
        this.requests = requests;
        this.properties = properties;
        this.events = events;
        this.clock = clock;
    }

    // ------------------------------------------------------------------ commands

    public ConversationView start(String employeeId) {
        EmployeeContext context = employees.contextFor(employeeId);
        Conversation c = new Conversation(employeeId, now());
        String names = catalog.intakeCategories().stream().map(CategoryDefinition::name)
                .map(String::toLowerCase).collect(Collectors.joining(", "));
        c.say("assistant", "Hi " + firstName(context) + ". Tell me what you need in your own words. "
                + "I can handle " + names + ". Anything else goes to a buyer.", now());
        c.setQuickReplies(List.of(
                "I need a laptop for a new designer starting next month",
                "The printer on the 3rd floor is out of toner",
                "Two developers join on December 1st"));
        return view(conversations.save(c));
    }

    public ConversationView handleMessage(String conversationId, String text) {
        Conversation c = load(conversationId);
        if (!c.isOpen()) {
            throw new IllegalStateException("This conversation is closed (" + c.getStatus() + "). Start a new one.");
        }
        EmployeeContext context = employees.contextFor(c.getEmployeeId());
        c.say("user", text, now());
        c.setStatus(Conversation.Status.COLLECTING);
        c.setQuickReplies(List.of());

        // 1. Classification: only until a category is chosen.
        if (c.getCategoryCode() == null) {
            ModelOutputs.Classification cls = model.call("classify", c.getId(),
                    IntakePrompts.withHistory(IntakePrompts.classificationSystem(catalog.intakeCategories()), c.getTurns()),
                    ModelOutputs.Classification.class);
            Optional<CategoryDefinition> category = catalog.findCategory(cls.categoryCode())
                    .filter(CategoryDefinition::intakeEnabled);
            if (cls.intent() == ModelOutputs.Intent.PURCHASE_REQUEST && category.isEmpty()) {
                return handOff(c, "Non-catalog purchase: needs a buyer", orDefault(cls.reply(),
                        "This is not one of our standard items, so a buyer from procurement will contact you."));
            }
            if (category.isEmpty()) {
                c.say("assistant", orDefault(cls.reply(),
                        "I can help you buy standard equipment. What do you need?"), now());
                return view(conversations.save(c));
            }
            c.startCategory(category.get().code());
            prefillFromContext(c, category.get(), context);
        }

        CategoryDefinition category = catalog.category(c.getCategoryCode());

        // 2. Extraction, bounded by the template, the catalog and the requester's context.
        DraftAssessment before = evaluator.assess(category, c.values(), context);
        String system = IntakePrompts.extractionSystem(category, catalog.itemsOf(category.code()), catalog.kits(),
                employees.departments(), context, c.values(), before.missingFields(), today());
        ModelOutputs.Extraction extraction = model.call("extract", c.getId(),
                IntakePrompts.withHistory(system, c.getTurns()), ModelOutputs.Extraction.class);

        // 3. Normalise and keep only valid values.
        List<String> problems = applyExtraction(c, category, context, extraction);
        c.setFieldProblems(problems);
        if (extraction.requirements() != null) {
            c.setRequirements(extraction.requirements().stream()
                    .filter(r -> r != null && notBlank(r.description())).toList());
        }
        if (notBlank(extraction.rationale())) {
            c.setRationale(extraction.rationale().trim());
        }
        String reply = notBlank(extraction.reply()) ? extraction.reply().trim() : null;

        // 4. Code, not the model, checks the conditions against the catalog and picks a better tier if one fits.
        String switchNote = switchToBestTier(c, category, context);

        // The employee explicitly chose a non-standard request: hand the structured draft to a buyer.
        if (Boolean.TRUE.equals(extraction.escalateToBuyer())) {
            return submit(c, category, context, true, reply);
        }

        // 5. Decide the next step from the deterministic assessment, not from the model.
        DraftAssessment after = assess(c, category, context);
        if (after.readyToSubmit()) {
            c.setStatus(Conversation.Status.AWAITING_CONFIRMATION);
            c.say("assistant", join(reply, join(switchNote, confirmationText(after, c))), now());
            c.setQuickReplies(after.unmetMustHaves().isEmpty() ? List.of()
                    : List.of("The standard option is fine", "Send it to a buyer as a special request"));
        } else if (reply == null && c.nextClarificationRound() > properties.maxClarificationRounds()) {
            // Turns where the employee asked us something do not count as unanswered questions.
            return handOff(c, "Still missing after " + properties.maxClarificationRounds() + " questions: "
                    + labels(category, after.missingFields()),
                    "I'll pass this to a buyer with what we have so far; they will contact you for the rest.");
        } else {
            c.say("assistant", join(reply, join(switchNote, clarificationText(category, after, extraction, problems))), now());
            c.setQuickReplies(extraction.options());
        }
        return view(conversations.save(c));
    }

    /**
     * Submits the draft. {@code special = false}: the standard catalog option, fully automated.
     * {@code special = true}: a special request with the unmet conditions, routed to a buyer.
     */
    public ConversationView confirm(String conversationId, boolean special) {
        Conversation c = load(conversationId);
        if (!c.isOpen() || c.getCategoryCode() == null) {
            throw new IllegalStateException("Nothing to submit yet.");
        }
        EmployeeContext context = employees.contextFor(c.getEmployeeId());
        CategoryDefinition category = catalog.category(c.getCategoryCode());
        if (special) {
            return submit(c, category, context, true, null);
        }
        if (c.getStatus() != Conversation.Status.AWAITING_CONFIRMATION) {
            throw new IllegalStateException("Nothing to confirm yet.");
        }
        DraftAssessment assessment = assess(c, category, context);
        if (!assessment.readyToSubmit()) {
            c.setStatus(Conversation.Status.COLLECTING);
            c.say("assistant", "Something changed and the request is no longer complete. "
                    + clarificationText(category, assessment, null, List.of()), now());
            return view(conversations.save(c));
        }
        return submit(c, category, context, false, null);
    }

    public ConversationView cancel(String conversationId) {
        Conversation c = load(conversationId);
        if (c.isOpen()) {
            c.setStatus(Conversation.Status.CANCELLED);
            c.say("assistant", "Cancelled. Nothing was submitted.", now());
            conversations.save(c);
        }
        return view(c);
    }

    public ConversationView get(String conversationId) {
        return view(load(conversationId));
    }

    // ------------------------------------------------------------------ steps

    private ConversationView submit(Conversation c, CategoryDefinition category, EmployeeContext context,
                                    boolean special, String reply) {
        DraftAssessment a = assess(c, category, context);
        List<String> specialRequirements = List.of();
        if (special) {
            specialRequirements = a.unmetMustHaves().isEmpty()
                    ? List.of("Employee asked for a non-standard request") : a.unmetMustHaves();
        }
        PurchaseRequest request = requests.submit(new NewRequest(CHANNEL, c.getId(), context, category,
                c.values(), c.sources(), a.lines(), a.estimatedTotal(), properties.currency(), a.warnings(),
                specialRequirements, a.checks(), c.originalWords(), c.getRationale()));
        c.submitted(request.getId());
        PurchaseRequest current = requests.get(request.getId());
        String message = special
                ? "Sent to procurement as special request " + current.getNumber() + ". It is not in the standard "
                  + "catalog, so a buyer will source and price it individually; it does not go through automatic "
                  + "approval. Procurement's service level is a reply within " + properties.buyerResponseDays()
                  + " working days."
                : "Submitted as " + current.getNumber() + ". Status: " + current.getStatus()
                  + ". You can follow it on the Pool & Orders page.";
        c.say("assistant", join(reply, message), now());
        c.setQuickReplies(List.of());
        return view(conversations.save(c));
    }

    /**
     * For categories where the employee picks one SKU: if the selected tier fails a must-have that
     * another tier meets, switch to that tier. Deterministic, so the same request always maps the same way.
     * Returns a sentence for the employee when a switch happened.
     */
    private String switchToBestTier(Conversation c, CategoryDefinition category, EmployeeContext context) {
        if (category.resolution() != ResolutionStrategy.DIRECT_SKU || c.getRequirements().isEmpty()) {
            return null;
        }
        Optional<CatalogItem> current = FieldValues.string(c.values(), "item").flatMap(catalog::findItem);
        if (current.isEmpty()) {
            return null;
        }
        long currentFailures = matcher.failedMusts(current.get(), c.getRequirements());
        if (currentFailures == 0) {
            return null;
        }
        Optional<CatalogItem> better = matcher.bestMatch(catalog.itemsOf(category.code()), c.getRequirements());
        if (better.isEmpty() || matcher.failedMusts(better.get(), c.getRequirements()) >= currentFailures) {
            return null; // no tier is strictly better: keep the model's choice
        }
        c.put("item", better.get().sku(), Conversation.Source.INFERRED);
        c.setRationale("Switched from " + current.get().name() + " to " + better.get().name()
                + ": by the catalog data it meets more of your must-have requirements.");
        return "I changed the option to " + better.get().name()
                + ", the standard item that meets more of your must-have requirements.";
    }

    /** Fields the system can answer itself are never asked: site and department from HR data, flags from constants. */
    private void prefillFromContext(Conversation c, CategoryDefinition category, EmployeeContext context) {
        for (FieldSpec f : category.fields()) {
            if (f.defaultFrom() == null) {
                continue;
            }
            if (f.defaultFrom().equals("employee.site")) {
                c.put(f.name(), context.employee().site(), Conversation.Source.CONTEXT);
            } else if (f.defaultFrom().equals("employee.department")) {
                c.put(f.name(), context.employee().department(), Conversation.Source.CONTEXT);
            } else if (f.defaultFrom().startsWith("const:")) {
                Object value = normalizer.normalize(f, f.defaultFrom().substring(6), category, context, today()).value();
                if (value != null) {
                    c.put(f.name(), value, Conversation.Source.CONTEXT);
                }
            }
        }
    }

    private List<String> applyExtraction(Conversation c, CategoryDefinition category, EmployeeContext context,
                                         ModelOutputs.Extraction extraction) {
        List<String> problems = new ArrayList<>();
        if (extraction.fields() == null) {
            return problems;
        }
        String employeeWords = c.originalWords();
        for (Map.Entry<String, ModelOutputs.ProposedValue> entry : extraction.fields().entrySet()) {
            Optional<FieldSpec> spec = category.field(entry.getKey());
            ModelOutputs.ProposedValue proposed = entry.getValue();
            if (spec.isEmpty() || proposed == null) {
                continue; // the model proposed a field the template does not have: ignore it
            }
            FieldNormalizer.Result result = normalizer.normalize(spec.get(), proposed.value(), category, context, today());
            if (result.isOk()) {
                Conversation.Source source = proposed.toSource();
                // The model may not label "urgent" as said by the employee unless they actually said it.
                if (spec.get().name().equals("urgent") && Boolean.TRUE.equals(result.value())
                        && source == Conversation.Source.STATED && !URGENT_WORDS.matcher(employeeWords).find()) {
                    source = Conversation.Source.INFERRED;
                }
                c.put(spec.get().name(), result.value(), source);
            } else if (result.problem() != null) {
                problems.add(result.problem());
            }
        }
        return problems;
    }

    private ConversationView handOff(Conversation c, String reason, String message) {
        c.handOff(reason);
        c.say("assistant", message, now());
        c.setQuickReplies(List.of());
        Conversation saved = conversations.save(c);
        events.publishEvent(new Events.IntakeHandedOff(saved.getId(), reason, now()));
        return view(saved);
    }

    private String clarificationText(CategoryDefinition category, DraftAssessment a,
                                     ModelOutputs.Extraction extraction, List<String> problems) {
        StringBuilder sb = new StringBuilder();
        for (String p : problems) {
            sb.append(p).append(". ");
        }
        a.violations().stream().filter(RuleViolation::blocking).forEach(v -> sb.append(v.message()).append(" "));
        if (extraction != null && notBlank(extraction.question())) {
            sb.append(extraction.question());
        } else if (!a.missingFields().isEmpty()) {
            sb.append("Could you tell me: ").append(labels(category, a.missingFields())).append("?");
        }
        return sb.toString().trim();
    }

    /** Shows exactly what will be ordered, specs and requirement checks included, so nothing is a black box. */
    private String confirmationText(DraftAssessment a, Conversation c) {
        StringBuilder sb = new StringBuilder("Here is your request, ready to submit:");
        a.lines().forEach(l -> {
            sb.append("\n- ").append(l.quantity()).append(" x ").append(l.name());
            if (l.specs() != null && !l.specs().isEmpty()) {
                sb.append(" (").append(l.specs().entrySet().stream()
                        .map(e -> e.getKey() + ": " + e.getValue()).collect(Collectors.joining(", "))).append(')');
            }
        });
        sb.append("\nEstimated total: ").append(a.estimatedTotal()).append(" ").append(properties.currency()).append('.');
        if (notBlank(c.getRationale())) {
            sb.append("\nWhy this option: ").append(c.getRationale());
        }
        a.warnings().forEach(w -> sb.append("\nNote: ").append(w.message()));
        List<String> unmet = a.unmetMustHaves();
        if (!unmet.isEmpty()) {
            sb.append("\nThe standard catalog does not meet: ").append(String.join("; ", unmet))
                    .append(". You can go ahead with this standard item, or send the request to a buyer, who will "
                            + "source and price it individually (procurement replies within ")
                    .append(properties.buyerResponseDays()).append(" working days).");
        } else {
            sb.append("\nPress Confirm to submit, ask me anything about it, or tell me what to change.");
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------ view

    private DraftAssessment assess(Conversation c, CategoryDefinition category, EmployeeContext context) {
        return evaluator.assess(category, c.values(), context, c.getRequirements());
    }

    private ConversationView view(Conversation c) {
        CategoryDefinition category = catalog.findCategory(c.getCategoryCode()).orElse(null);
        List<ConversationView.FieldView> fields = new ArrayList<>();
        DraftAssessment assessment = null;
        if (category != null) {
            for (FieldSpec f : category.fields()) {
                Conversation.FieldValue v = c.getFields().get(f.name());
                fields.add(new ConversationView.FieldView(f.name(), f.label(), f.type().name(), f.required(),
                        v == null ? null : v.value(), v == null ? null : v.source().name()));
            }
            assessment = assess(c, category, employees.contextFor(c.getEmployeeId()));
        }
        List<RuleViolation> issues = new ArrayList<>();
        c.getFieldProblems().forEach(p -> issues.add(RuleViolation.error(null, p)));
        if (assessment != null) {
            issues.addAll(assessment.violations());
        }
        String costCenter = FieldValues.string(c.values(), "chargeTo").flatMap(employees::department)
                .map(d -> d.costCenter()).orElse(null);
        PurchaseRequest request = c.getRequestId() == null ? null : requests.get(c.getRequestId());
        return new ConversationView(c.getId(), c.getEmployeeId(), c.getStatus().name(),
                category == null ? null : category.code(), category == null ? null : category.name(),
                c.getTurns(), fields,
                assessment == null ? List.of() : assessment.lines(),
                assessment == null ? null : assessment.estimatedTotal(),
                properties.currency(), issues,
                assessment == null ? List.of() : assessment.missingFields(),
                c.getQuickReplies(), c.getRationale(),
                assessment == null ? List.of() : assessment.checks(),
                assessment == null ? List.of() : assessment.unmetMustHaves(),
                costCenter,
                c.getHandoffReason(), c.getRequestId(),
                request == null ? null : request.getNumber(),
                request == null ? null : request.getStatus().name());
    }

    // ------------------------------------------------------------------ helpers

    private Conversation load(String id) {
        return conversations.findById(id).orElseThrow(() -> new NotFoundException("Unknown conversation " + id));
    }

    private static String labels(CategoryDefinition category, List<String> names) {
        return names.stream().map(n -> category.field(n).map(FieldSpec::label).orElse(n))
                .map(s -> s.toLowerCase(Locale.ROOT)).collect(Collectors.joining(", "));
    }

    private static String firstName(EmployeeContext context) {
        return context.employee().name().split(" ")[0];
    }

    private static boolean notBlank(String s) {
        return s != null && !s.isBlank() && !"null".equalsIgnoreCase(s.trim());
    }

    private static String join(String first, String second) {
        if (first == null || first.isBlank()) {
            return second;
        }
        return second == null || second.isBlank() ? first : first + "\n\n" + second;
    }

    private static String orDefault(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    private Instant now() {
        return Instant.now(clock);
    }

    private LocalDate today() {
        return LocalDate.now(clock);
    }
}
