package com.compras.procurement.intake;

import com.compras.procurement.catalog.CatalogService;
import com.compras.procurement.catalog.CategoryDefinition;
import com.compras.procurement.catalog.FieldSpec;
import com.compras.procurement.context.EmployeeContext;
import com.compras.procurement.context.EmployeeContextService;
import com.compras.procurement.llm.ModelGateway;
import com.compras.procurement.request.NewRequest;
import com.compras.procurement.request.PurchaseRequest;
import com.compras.procurement.request.RequestService;
import com.compras.procurement.rules.RuleViolation;
import com.compras.procurement.shared.Events;
import com.compras.procurement.shared.NotFoundException;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Orchestrates the intake dialogue:
 * <ol>
 *   <li>classify the message and pick the category template (model)</li>
 *   <li>prefill what the system already knows (context, no model)</li>
 *   <li>extract field values from the dialogue (model, bounded by the template)</li>
 *   <li>normalise and validate every value (rules, no model)</li>
 *   <li>ask for what is missing, or show the structured request for confirmation</li>
 *   <li>on confirmation, store the standardised request and hand it downstream</li>
 * </ol>
 */
@Service
public class IntakeService {

    private static final String CHANNEL = "web-chat";

    private final ConversationRepository conversations;
    private final CatalogService catalog;
    private final EmployeeContextService employees;
    private final ModelGateway model;
    private final FieldNormalizer normalizer;
    private final DraftEvaluator evaluator;
    private final RequestService requests;
    private final IntakeProperties properties;
    private final ApplicationEventPublisher events;
    private final Clock clock;

    public IntakeService(ConversationRepository conversations, CatalogService catalog,
                         EmployeeContextService employees, ModelGateway model, FieldNormalizer normalizer,
                         DraftEvaluator evaluator, RequestService requests, IntakeProperties properties,
                         ApplicationEventPublisher events, Clock clock) {
        this.conversations = conversations;
        this.catalog = catalog;
        this.employees = employees;
        this.model = model;
        this.normalizer = normalizer;
        this.evaluator = evaluator;
        this.requests = requests;
        this.properties = properties;
        this.events = events;
        this.clock = clock;
    }

    // ------------------------------------------------------------------ commands

    public ConversationView start(String employeeId) {
        EmployeeContext context = employees.contextFor(employeeId);
        Conversation c = new Conversation(employeeId, now());
        String names = catalog.intakeCategories().stream().map(CategoryDefinition::name)
                .map(String::toLowerCase).collect(Collectors.joining(", "));
        c.say("assistant", "Hi " + firstName(context) + ". Tell me what you need in your own words. "
                + "I can handle " + names + ". Anything else goes to a buyer.", now());
        c.setQuickReplies(List.of(
                "I need a laptop for a new designer starting next month",
                "The printer on the 3rd floor is out of toner",
                "Two developers join on December 1st"));
        return view(conversations.save(c));
    }

    public ConversationView handleMessage(String conversationId, String text) {
        Conversation c = load(conversationId);
        if (!c.isOpen()) {
            throw new IllegalStateException("This conversation is closed (" + c.getStatus() + "). Start a new one.");
        }
        EmployeeContext context = employees.contextFor(c.getEmployeeId());
        c.say("user", text, now());
        c.setStatus(Conversation.Status.COLLECTING);
        c.setQuickReplies(List.of());

        // 1. Classification: only until a category is chosen.
        if (c.getCategoryCode() == null) {
            ModelOutputs.Classification cls = model.call("classify", c.getId(),
                    IntakePrompts.withHistory(IntakePrompts.classificationSystem(catalog.intakeCategories()), c.getTurns()),
                    ModelOutputs.Classification.class);
            Optional<CategoryDefinition> category = catalog.findCategory(cls.categoryCode())
                    .filter(CategoryDefinition::intakeEnabled);
            if (cls.intent() == ModelOutputs.Intent.PURCHASE_REQUEST && category.isEmpty()) {
                return handOff(c, "Non-catalog purchase: needs a buyer", orDefault(cls.reply(),
                        "This is not one of our standard items, so a buyer from procurement will contact you."));
            }
            if (category.isEmpty()) {
                c.say("assistant", orDefault(cls.reply(),
                        "I can help you buy standard equipment. What do you need?"), now());
                return view(conversations.save(c));
            }
            c.startCategory(category.get().code());
            prefillFromContext(c, category.get(), context);
        }

        CategoryDefinition category = catalog.category(c.getCategoryCode());

        // 2. Extraction, bounded by the template, the catalog and the requester's context.
        DraftAssessment before = evaluator.assess(category, c.values(), context);
        String system = IntakePrompts.extractionSystem(category, catalog.itemsOf(category.code()), catalog.kits(),
                context, c.values(), before.missingFields(), today());
        ModelOutputs.Extraction extraction = model.call("extract", c.getId(),
                IntakePrompts.withHistory(system, c.getTurns()), ModelOutputs.Extraction.class);

        // 3. Normalise and keep only valid values.
        List<String> problems = applyExtraction(c, category, context, extraction);
        c.setFieldProblems(problems);

        // 4. Decide the next step from the deterministic assessment, not from the model.
        DraftAssessment after = evaluator.assess(category, c.values(), context);
        if (after.readyToSubmit()) {
            c.setStatus(Conversation.Status.AWAITING_CONFIRMATION);
            c.say("assistant", confirmationText(after), now());
            c.setQuickReplies(List.of());
        } else if (c.nextClarificationRound() > properties.maxClarificationRounds()) {
            return handOff(c, "Still missing after " + properties.maxClarificationRounds() + " questions: "
                    + labels(category, after.missingFields()),
                    "I'll pass this to a buyer with what we have so far; they will contact you for the rest.");
        } else {
            c.say("assistant", clarificationText(category, after, extraction, problems), now());
            c.setQuickReplies(extraction.options());
        }
        return view(conversations.save(c));
    }

    public ConversationView confirm(String conversationId) {
        Conversation c = load(conversationId);
        if (c.getStatus() != Conversation.Status.AWAITING_CONFIRMATION) {
            throw new IllegalStateException("Nothing to confirm yet.");
        }
        EmployeeContext context = employees.contextFor(c.getEmployeeId());
        CategoryDefinition category = catalog.category(c.getCategoryCode());
        DraftAssessment assessment = evaluator.assess(category, c.values(), context);
        if (!assessment.readyToSubmit()) {
            c.setStatus(Conversation.Status.COLLECTING);
            c.say("assistant", "Something changed and the request is no longer complete. "
                    + clarificationText(category, assessment, null, List.of()), now());
            return view(conversations.save(c));
        }
        PurchaseRequest request = requests.submit(new NewRequest(CHANNEL, c.getId(), context, category,
                c.values(), c.sources(), assessment.lines(), assessment.estimatedTotal(), properties.currency(),
                assessment.warnings()));
        c.submitted(request.getId());
        PurchaseRequest current = requests.get(request.getId());
        c.say("assistant", "Submitted as " + current.getNumber() + ". Status: " + current.getStatus()
                + ". You can follow it on the Pool & Orders page.", now());
        return view(conversations.save(c));
    }

    public ConversationView cancel(String conversationId) {
        Conversation c = load(conversationId);
        if (c.isOpen()) {
            c.setStatus(Conversation.Status.CANCELLED);
            c.say("assistant", "Cancelled. Nothing was submitted.", now());
            conversations.save(c);
        }
        return view(c);
    }

    public ConversationView get(String conversationId) {
        return view(load(conversationId));
    }

    // ------------------------------------------------------------------ steps

    /** Fields the system can answer itself are never asked: delivery site from HR data, flags from constants. */
    private void prefillFromContext(Conversation c, CategoryDefinition category, EmployeeContext context) {
        for (FieldSpec f : category.fields()) {
            if (f.defaultFrom() == null) {
                continue;
            }
            if (f.defaultFrom().equals("employee.site")) {
                c.put(f.name(), context.employee().site(), Conversation.Source.CONTEXT);
            } else if (f.defaultFrom().startsWith("const:")) {
                Object value = normalizer.normalize(f, f.defaultFrom().substring(6), category, context, today()).value();
                if (value != null) {
                    c.put(f.name(), value, Conversation.Source.CONTEXT);
                }
            }
        }
    }

    private List<String> applyExtraction(Conversation c, CategoryDefinition category, EmployeeContext context,
                                         ModelOutputs.Extraction extraction) {
        List<String> problems = new ArrayList<>();
        if (extraction.fields() == null) {
            return problems;
        }
        for (Map.Entry<String, ModelOutputs.ProposedValue> entry : extraction.fields().entrySet()) {
            Optional<FieldSpec> spec = category.field(entry.getKey());
            ModelOutputs.ProposedValue proposed = entry.getValue();
            if (spec.isEmpty() || proposed == null) {
                continue; // the model proposed a field the template does not have: ignore it
            }
            FieldNormalizer.Result result = normalizer.normalize(spec.get(), proposed.value(), category, context, today());
            if (result.isOk()) {
                c.put(spec.get().name(), result.value(), proposed.toSource());
            } else if (result.problem() != null) {
                problems.add(result.problem());
            }
        }
        return problems;
    }

    private ConversationView handOff(Conversation c, String reason, String message) {
        c.handOff(reason);
        c.say("assistant", message, now());
        c.setQuickReplies(List.of());
        Conversation saved = conversations.save(c);
        events.publishEvent(new Events.IntakeHandedOff(saved.getId(), reason, now()));
        return view(saved);
    }

    private String clarificationText(CategoryDefinition category, DraftAssessment a,
                                     ModelOutputs.Extraction extraction, List<String> problems) {
        StringBuilder sb = new StringBuilder();
        for (String p : problems) {
            sb.append(p).append(". ");
        }
        a.violations().stream().filter(RuleViolation::blocking).forEach(v -> sb.append(v.message()).append(" "));
        if (extraction != null && extraction.question() != null && !extraction.question().isBlank()) {
            sb.append(extraction.question());
        } else if (!a.missingFields().isEmpty()) {
            sb.append("Could you tell me: ").append(labels(category, a.missingFields())).append("?");
        }
        return sb.toString().trim();
    }

    private String confirmationText(DraftAssessment a) {
        StringBuilder sb = new StringBuilder("Here is your request, ready to submit:");
        a.lines().forEach(l -> sb.append("\n- ").append(l.quantity()).append(" x ").append(l.name()));
        sb.append("\nEstimated total: ").append(a.estimatedTotal()).append(" ").append(properties.currency()).append('.');
        a.warnings().forEach(w -> sb.append("\nNote: ").append(w.message()));
        sb.append("\nPress Confirm to submit, or tell me what to change.");
        return sb.toString();
    }

    // ------------------------------------------------------------------ view

    private ConversationView view(Conversation c) {
        CategoryDefinition category = catalog.findCategory(c.getCategoryCode()).orElse(null);
        List<ConversationView.FieldView> fields = new ArrayList<>();
        DraftAssessment assessment = null;
        if (category != null) {
            for (FieldSpec f : category.fields()) {
                Conversation.FieldValue v = c.getFields().get(f.name());
                fields.add(new ConversationView.FieldView(f.name(), f.label(), f.type().name(), f.required(),
                        v == null ? null : v.value(), v == null ? null : v.source().name()));
            }
            assessment = evaluator.assess(category, c.values(), employees.contextFor(c.getEmployeeId()));
        }
        List<RuleViolation> issues = new ArrayList<>();
        c.getFieldProblems().forEach(p -> issues.add(RuleViolation.error(null, p)));
        if (assessment != null) {
            issues.addAll(assessment.violations());
        }
        PurchaseRequest request = c.getRequestId() == null ? null : requests.get(c.getRequestId());
        return new ConversationView(c.getId(), c.getEmployeeId(), c.getStatus().name(),
                category == null ? null : category.code(), category == null ? null : category.name(),
                c.getTurns(), fields,
                assessment == null ? List.of() : assessment.lines(),
                assessment == null ? null : assessment.estimatedTotal(),
                properties.currency(), issues,
                assessment == null ? List.of() : assessment.missingFields(),
                c.getQuickReplies(), c.getHandoffReason(), c.getRequestId(),
                request == null ? null : request.getNumber(),
                request == null ? null : request.getStatus().name());
    }

    // ------------------------------------------------------------------ helpers

    private Conversation load(String id) {
        return conversations.findById(id).orElseThrow(() -> new NotFoundException("Unknown conversation " + id));
    }

    private static String labels(CategoryDefinition category, List<String> names) {
        return names.stream().map(n -> category.field(n).map(FieldSpec::label).orElse(n))
                .map(String::toLowerCase).collect(Collectors.joining(", "));
    }

    private static String firstName(EmployeeContext context) {
        return context.employee().name().split(" ")[0];
    }

    private static String orDefault(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    private Instant now() {
        return Instant.now(clock);
    }

    private LocalDate today() {
        return LocalDate.now(clock);
    }
}
